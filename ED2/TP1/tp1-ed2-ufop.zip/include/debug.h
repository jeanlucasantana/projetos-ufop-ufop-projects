#ifndef DEBUG_H
#define DEBUG_H

//debug para vizualizar arvore b(raiz)
void debug_no_raiz_arvore_b(const char* caminho);

#endif
