//arquivo de especificacao do automato e suas respectivas funcoes
#ifndef AUTOMATO_H
#define AUTOMATO_H

#include "matriz.h"

//funcao para evolucao do reticulado(nao recursiva)

void evoluirReticulado(listaLinhas* linhas, listaColunas* colunas, listaLinhas* novasLinhas, listaColunas* novasColunas, int tam);

#endif 
